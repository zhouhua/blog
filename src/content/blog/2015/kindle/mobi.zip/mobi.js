/**
 * @file
 * @author Zhouhua( zhouhua@baidu.com )
 */

var fs = require('fs');
var webPage = require('webpage');
var system = require('system');
var process = require("child_process");


var page = webPage.create();
var args = system.args;

if (args.length === 1) {
    console.log('请输入要采集的网址！');
    phantom.exit(-1);
}
var url = args[1];


var outputPath = 'output';
var scope = {
    content: '',
    page: 1,
    counts: 0
};

var r = /^(.+)-([0-9]+)\.shtml$/;
var matches = url.match(r);
if (matches.length === 3) {
    spider(scope);
}
else {
    console.log('无法解析url');
    phantom.exit(-1);
}

page.onResourceRequested = function(requestData, request) {
    if ((/http:\/\/.+?\.css/gi).test(requestData['url'])) {
        request.abort();
    }
    if ((/http:\/\/.*baidu/gi).test(requestData['url'])) {
        request.abort();
    }
    if ((/http:\/\/.*jd/gi).test(requestData['url'])) {
        request.abort();
    }
    if ((/http:\/\/.+?\.jpg/gi).test(requestData['url'])) {
        request.abort();
    }
    if ((/http:\/\/.+?\.png/gi).test(requestData['url'])) {
        request.abort();
    }
    if ((/http:\/\/.+?\.js/gi).test(requestData['url'])) {
        request.abort();
    }
};

function spider(scope) {
    var url = matches[1] + '-' + scope.page + '.shtml';
    console.log(url);
    page.open(url, function (status) {
        console.log(status);
        if (status === 'success') {
            page.injectJs('jq.js');
            scope = page.evaluate(function (scope) {
                var $ = jQuery;
                if (!scope.counts) {
                    scope.counts = bbsGlobal.pageCount;
                    scope.hostName = bbsGlobal.dashang.getName;
                    scope.title=$('title').text();
                }

                var posts = $('[_host="' + scope.hostName + '"]');
                posts.each(function () {
                    var $this = $(this);
                    scope.content += '<div class="post-content">' + $this.find('.bbs-content').html() +
                        '</div><br/><hr/>';
                });
                return scope;
            }, scope);
            console.log(scope.page+' / '+scope.counts);
            if (scope.page === scope.counts) {
                writer(scope);
            }
            else {
                scope.page++;
                spider(scope);
            }
        }
        else {
            console.log('无法打开' + url);
            phantom.exit(-1);
        }
    });
}

function writer(scope) {
    var html='<!DOCTYPE html><html><head lang="en"><title>'+
        scope.title+
        '</title></head><body>'+
        scope.content.replace(/<br\/>$/, '')+
        '</body></html>';
    var path=outputPath+'/'+scope.title.replace(/[ \\\/:,，\?？\-\.\+]/g,'')+'.html';
    fs.write(path,html,{
        charset:'gb18030'
    });
    var child = process.spawn("./kindlegen.exe", [path]);

    child.stderr.on("data", function (data) {
        console.log("spawnSTDERR:", JSON.stringify(data))
    });

    child.on("exit", function (code) {
        console.log('finish!');
        phantom.exit(-1);
    })
}